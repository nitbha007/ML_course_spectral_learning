## Wrapper for mace.cli.run_train.main ##

from mace_dipole_core.cli.run_train import main

if __name__ == "__main__":
    main()
