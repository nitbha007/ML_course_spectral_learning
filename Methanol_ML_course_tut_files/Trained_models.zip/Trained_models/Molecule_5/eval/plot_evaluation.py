import subprocess

# Run the command to evaluate configurations
command = """
python3 "/project/project_462000612/Nitik_py_env/MACE_dipole_py_env/eval_mu_alpha.py" \
    --configs="../result_out/output.xyz" \
    --model="/scratch/project_462000612/Nitik_work/QM9_model_training/MACE/MACE_dipole_model/main_model/16_channels/model_1/model_1.model" \
    --output="./MACE_prediction.xyz" \
    --default_dtype="float32" \
    --info_prefix=""
"""
subprocess.run(command, shell=True)

