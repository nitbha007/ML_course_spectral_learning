#!/bin/bash
#SBATCH --account=project_462000612
#SBATCH --job-name=data_gen   # Job name
#SBATCH --partition=small
#SBATCH --nodes=1
#SBATCH --cpus-per-task=40
#SBATCH --mem-per-cpu=1700
#SBATCH --time=0-00:59:00

module purge

export EBU_USER_PREFIX=/project/project_462000612/Nitik_easy_build_paths/EasyBuild
module load CrayEnv
module load PyTorch/2.2.2-rocm-5.6.1-python-3.10-vllm-0.4.0.post1-singularity-20240617_MACE_dipole

export SINGULARITY_BIND="$SINGULARITY_BIND,/usr/bin/sacct,/usr/bin/sacctmgr,/usr/bin/salloc,/usr/bin/sattach,/usr/bin/sbatch,/usr/bin/sbcast,/usr/bin/scancel,/usr/bin/scontrol,/usr/bin/scrontab,/usr/bin/sdiag,/usr/bin/sinfo,/usr/bin/sprio,/usr/bin/squeue,/usr/bin/sreport,/usr/bin/srun,/usr/bin/sshare,/usr/bin/sstat,/usr/bin/strigger,/usr/bin/sview,/usr/bin/sgather,/usr/lib64/slurm/,/etc/slurm,/etc/passwd,/usr/lib64/libmunge.so.2,/run/munge,/var/lib/misc,/etc/nsswitch.conf"

echo $SIF
srun singularity exec $SIF python3 plot_evaluation.py 

echo "finished"
