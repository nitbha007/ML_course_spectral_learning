#!/bin/bash
#SBATCH --account=project_462000612
#SBATCH --partition=small-g
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=7
#SBATCH --gpus-per-node=1
#SBATCH --time=0-03:45:00

module purge

export EBU_USER_PREFIX=/project/project_462000612/Nitik_easy_build_paths/EasyBuild
module load CrayEnv
module load seff
module load PyTorch/2.2.2-rocm-5.6.1-python-3.10-vllm-0.4.0.post1-singularity-20240617

export SINGULARITY_BIND="$SINGULARITY_BIND,/usr/bin/sacct,/usr/bin/sacctmgr,/usr/bin/salloc,/usr/bin/sattach,/usr/bin/sbatch,/usr/bin/sbcast,/usr/bin/scancel,/usr/bin/scontrol,/usr/bin/scrontab,/usr/bin/sdiag,/usr/bin/sinfo,/usr/bin/sprio,/usr/bin/squeue,/usr/bin/sreport,/usr/bin/srun,/usr/bin/sshare,/usr/bin/sstat,/usr/bin/strigger,/usr/bin/sview,/usr/bin/sgather,/usr/lib64/slurm/,/etc/slurm,/etc/passwd,/usr/lib64/libmunge.so.2,/run/munge,/var/lib/misc,/etc/nsswitch.conf"

echo $SIF

start_time=$(date +%s)
echo "Job started at $(date)"

# Execute the script
srun singularity exec $SIF bash run_lumi.sh

end_time=$(date +%s)
elapsed_time=$(($end_time - $start_time))

# Calculate hours, minutes, and seconds
hours=$(($elapsed_time / 3600))
minutes=$((($elapsed_time % 3600) / 60))
seconds=$(($elapsed_time % 60))

echo "Job finished at $(date)"
echo "Elapsed time: $hours hours, $minutes minutes, and $seconds seconds"

echo "finished"
