import argparse
import os
import time
import subprocess

import ase.io
from ase import Atoms
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from ase import units
from ase.md.langevin import Langevin
from ase.md.velocitydistribution import MaxwellBoltzmannDistribution
from mace.calculators.mace import MACECalculator

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", help="path to XYZ configurations", required=True)
    parser.add_argument(
        "--config_index", help="index of configuration", type=int, default=-1
    )
    parser.add_argument(
        "--error_threshold", help="error threshold", type=float, default=0.1
    )
    parser.add_argument("--temperature_K", help="temperature", type=float, default=300)
    parser.add_argument("--friction", help="friction", type=float, default=0.01)
    parser.add_argument("--timestep", help="timestep", type=float, default=1)
    parser.add_argument("--nsteps", help="number of steps", type=int, default=1000)
    parser.add_argument(
        "--nprint", help="number of steps between prints", type=int, default=10
    )
    parser.add_argument(
        "--nsave", help="number of steps between saves", type=int, default=10
    )
    parser.add_argument(
        "--ncheckerror", help="number of steps between saves", type=int, default=10
    )

    parser.add_argument(
        "--model",
        help="path to model. Use wildcards to add multiple models as committe eg "
        "(`mace_*.model` to load mace_1.model, mace_2.model) ",
        required=True,
    )
    parser.add_argument("--output", help="output path", required=True)
    parser.add_argument(
        "--device",
        help="select device",
        type=str,
        choices=["cpu", "cuda"],
        default="cuda",
    )
    parser.add_argument(
        "--default_dtype",
        help="set default dtype",
        type=str,
        choices=["float32", "float64"],
        default="float64",
    )
    parser.add_argument(
        "--compute_stress",
        help="compute stress",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--info_prefix",
        help="prefix for energy, forces and stress keys",
        type=str,
        default="MACE_",
    )
    return parser.parse_args()


def printenergy(dyn, start_time=None):  # store a reference to atoms in the definition.
    """Function to print the potential, kinetic and total energy."""
    a = dyn.atoms
    epot = a.get_potential_energy() / len(a)
    ekin = a.get_kinetic_energy() / len(a)
    if start_time is None:
        elapsed_time = 0
    else:
        elapsed_time = time.time() - start_time
    print(
        "%.1fs: Energy per atom: Epot = %.3feV  Ekin = %.3feV (T=%3.0fK)  "  # pylint: disable=C0209
        "Etot = %.3feV t=%.1ffs"
        % (
            elapsed_time,
            epot,
            ekin,
            ekin / (1.5 * units.kB),
            epot + ekin,
            dyn.get_time() / units.fs,
        ),
        flush=True,
    )


def save_config(dyn, fname):
    atomsi = dyn.atoms
    ase.io.write(fname, atomsi, append=True)

def main():
    args = parse_args()

    mace_fname = args.model
    atoms_fname = args.config
    atoms_index = args.config_index

    mace_calc = MACECalculator(
        model_paths=mace_fname,
        device=args.device,
        default_dtype=args.default_dtype,
    )

    NSTEPS = args.nsteps

    # Lists for data collection
    time_points = []
    total_energy_points = []
    temperature_points = []

    if os.path.exists(args.output):
        print("Trajectory exists. Continuing from last step.")
        atoms = ase.io.read(args.output, index=-1)
        #len_save = len(ase.io.read(args.output, ":"))
        #print("Last step: ", atoms.info["time"], "Number of configs: ", len_save)
        #NSTEPS -= len_save * args.nsave
    else:
        atoms = ase.io.read(atoms_fname, index=atoms_index)
        MaxwellBoltzmannDistribution(atoms, temperature_K=args.temperature_K)

    atoms.calc = mace_calc

    # We want to run MD with constant energy using the Langevin algorithm
    # with a time step of 5 fs, the temperature T and the friction
    # coefficient to 0.02 atomic units.
    dyn = Langevin(
        atoms=atoms,
        timestep=args.timestep * units.fs,
        temperature_K=args.temperature_K,
        friction=args.friction,
    )

    # Function to update data during the simulation
    def update_data(dyn):
        a = dyn.atoms
        epot = a.get_potential_energy() / len(a)
        ekin = a.get_kinetic_energy() / len(a)

        time_points.append(dyn.get_time() / units.fs)
        total_energy_points.append(epot + ekin)
        temperature_points.append(ekin / (1.5 * units.kB))

    # Attach the update_data function to the Langevin dynamics
    dyn.attach(update_data, interval=args.nsave, dyn=dyn)
    dyn.attach(printenergy, interval=args.nsave, dyn=dyn, start_time=time.time())
    dyn.attach(save_config, interval=args.nsave, dyn=dyn, fname=args.output)
    # Now run the dynamics
    dyn.run(NSTEPS)

    # Create plots after the simulation
    fig, ax = plt.subplots(2, 1, figsize=(6, 6), sharex='all', gridspec_kw={'hspace': 0, 'wspace': 0})

    #ax[0].set_xlabel('Time (fs)')
    ax[0].set_ylabel('Energy per atom (eV)', color='tab:red')
    ax[0].plot(np.array(time_points), total_energy_points, color='tab:red')
    ax[0].tick_params(axis='y', labelcolor='tab:red')

    ax[1].set_ylabel('Temperature (K)', color='tab:blue')
    ax[1].plot(np.array(time_points), temperature_points, color='tab:blue')
    ax[1].tick_params(axis='y', labelcolor='tab:blue')

    plt.savefig('MD_analysis.pdf', format='pdf')

    # Save data to a CSV file in the temperature folder
    plot_data_file = "plot_data.csv"
    with open(plot_data_file, "w") as f:
        f.write("Time (fs),Total Energy (eV),Temperature (K)\n")
        for Time_values, energy_values, temperature_values in zip(time_points, total_energy_points, temperature_points):
            f.write(f"{Time_values},{energy_values},{temperature_values}\n")

    # After the MD is done, we can predict
    # dipole moment for these structures to
    # obtain the IR spectra using Auto-corr. function
    # for doing this change directory to "eval"

    eval_dir = os.path.join(os.getcwd(), "eval")
    os.chdir(eval_dir)
    print(f"Changed directory to {eval_dir}")

    # Execute the sbatch command
    try:
        subprocess.run(["sbatch", "run.sh"], check=True)
        print("sbatch run.sh executed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error executing sbatch: {e}")

if __name__ == "__main__":
    start_main_time = time.time()  # Record the start time for main()

    main()  # Run the main function

    end_main_time = time.time()  # Record the end time for main()

    elapsed_main_time = end_main_time - start_main_time  # Calculate elapsed time in seconds
    print(f"Total runtime of main(): {elapsed_main_time:.2f} seconds")  # Print the runtime


