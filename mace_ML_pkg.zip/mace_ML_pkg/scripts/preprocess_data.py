## Wrapper for mace.cli.run_train.main ##

from mace.cli.preprocess_data import main

if __name__ == "__main__":
    main()
